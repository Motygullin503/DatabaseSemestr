CREATE PROCEDURE findServicesById_procedure
@org_id int
AS
SET NOCOUNT ON
SELECT os.service_name FROM Org_Specializations os WHERE os.org_id=@org_id