CREATE VIEW contract_view 
AS
SELECT c.contract_id, o.name Organization, os.service_name Service FROM Contracts c 
LEFT JOIN (Org_Specializations os LEFT JOIN Organizations o ON (os.org_id = o.org_id)  ) ON (c.spec_org_id = os.spec_org_id)